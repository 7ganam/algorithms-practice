# Find the minimum sub array to sort to make the whole array sorted

- solution is found by noting some simple facts
    - if the min peak isn’t at the first index the first index of the array should be sorted .. same for the max index
        
        ![Untitled](Find%20the%20minimum%20sub%20array%20to%20sort%20to%20make%20the%20who%20e15540ae20ac4d05b0f1d5b0b198eec8/Untitled.png)
        
    - if the max is in the last index and the min is at the first index then second min and max will determin where to start
        
        ![Untitled](Find%20the%20minimum%20sub%20array%20to%20sort%20to%20make%20the%20who%20e15540ae20ac4d05b0f1d5b0b198eec8/Untitled%201.png)